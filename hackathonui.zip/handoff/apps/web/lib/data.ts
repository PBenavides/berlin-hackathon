import type { Owner, Building, Property, Unit, Vendor, VendorCase, Ticket, PipelineStage } from "./types";

// ============================================================
// OWNERS (top of the cascade — WEG / company / private)
// ============================================================
export const owners: Owner[] = [
  {
    id: "o1",
    name: "WEG Gartenstraße 42",
    type: "weg",
    contact: "Herr Klein (Verwaltungsbeirat)",
    email: "klein@weg-gartenstrasse.de",
    phone: "+49 30 9012 3456",
    language: "de",
    buildingsCount: 1,
    unitsCount: 8,
    monthlyRevenueEur: 7460,
    policies: [
      "Repairs > €1,000 require board sign-off (Verwaltungsbeirat)",
      "Annual Hausgeld review every March",
      "All correspondence in Sie-Form",
    ],
    decisions: [
      { date: "2026-03-12", text: "Approved €4,200 façade painting (5-year cycle)" },
      { date: "2026-01-08", text: "Renewed Heinz GmbH HVAC contract (3 years)" },
      { date: "2025-11-22", text: "Mobility flag added for Unit 3B (Herr Schmidt)" },
    ],
    notes: "WEG governance — 35 unit owners, 7 residential + 1 commercial unit. Beirat: Herr Klein.",
  },
  {
    id: "o2",
    name: "Müller Immobilien GmbH",
    type: "company",
    contact: "Frau Müller",
    email: "mueller@mueller-immo.de",
    phone: "+49 30 8845 0011",
    language: "de",
    buildingsCount: 2,
    unitsCount: 24,
    monthlyRevenueEur: 21800,
    policies: [
      "Repairs auto-approved up to €500",
      "Tenant communication in DE or EN per resident preference",
      "Monthly reporting on the 5th",
    ],
    decisions: [
      { date: "2026-02-14", text: "Approved auto-dispatch for Heinz GmbH up to €300" },
      { date: "2025-12-01", text: "Switched intercom vendor to Bekey" },
    ],
  },
];

// ============================================================
// BUILDINGS — share envelope, plumbing, vendors
// ============================================================
export const buildings: Building[] = [
  {
    id: "b1",
    name: "Gartenstraße 42",
    ownerId: "o1",
    address: "Gartenstraße 42, 10115 Berlin",
    city: "Berlin",
    yearBuilt: 1928,
    units: 8,
    systems: {
      hvac: "Vaillant gas central, replaced 2019",
      heating: "Vaillant ecoTEC plus, last service 2025-09",
      elevator: "None (4-storey walkup)",
      intercom: "Bekey digital, installed 2024-06",
    },
    vendors: ["v1", "v2", "v3"],
    notes: "Pre-war Altbau, listed building (Denkmalschutz). Façade restoration 2024.",
  },
  {
    id: "b2",
    name: "Brunnenstraße 17",
    ownerId: "o2",
    address: "Brunnenstraße 17, 10119 Berlin",
    city: "Berlin",
    yearBuilt: 2008,
    units: 14,
    systems: {
      hvac: "Buderus condensing boiler",
      heating: "District heating (Vattenfall)",
      elevator: "Schindler 3300, last cert 2025-04",
      intercom: "Siedle smart panel",
    },
    vendors: ["v1", "v4"],
  },
  {
    id: "b3",
    name: "Linienstraße 88",
    ownerId: "o2",
    address: "Linienstraße 88, 10119 Berlin",
    city: "Berlin",
    yearBuilt: 1995,
    units: 10,
    systems: {
      hvac: "Viessmann Vitodens",
      heating: "Gas central",
      elevator: "Otto",
      intercom: "Bekey",
    },
    vendors: ["v2", "v4"],
  },
];

// ============================================================
// PROPERTIES — what operators work in day-to-day (= a building, sometimes a portfolio)
// ============================================================
export const properties: Property[] = [
  {
    id: "p1",
    name: "Gartenstraße 42",
    buildingId: "b1",
    ownerId: "o1",
    city: "Berlin",
    units: 8,
    openTickets: 3,
    contextVersion: 11,
    phone: "+49 30 5550 1042",
    email: "garten42@buena.io",
  },
  {
    id: "p2",
    name: "Brunnenstraße 17",
    buildingId: "b2",
    ownerId: "o2",
    city: "Berlin",
    units: 14,
    openTickets: 1,
    contextVersion: 7,
    phone: "+49 30 5550 1117",
    email: "brunnen17@buena.io",
  },
  {
    id: "p3",
    name: "Linienstraße 88",
    buildingId: "b3",
    ownerId: "o2",
    city: "Berlin",
    units: 10,
    openTickets: 0,
    contextVersion: 4,
    phone: "+49 30 5550 1088",
    email: "linien88@buena.io",
  },
];

// ============================================================
// UNITS (Einheiten) — Eigentümer live here, not as a top-level layer
// ============================================================
export const units: Unit[] = [
  { id: "u-1a", propertyId: "p1", label: "1A", type: "residential", areaQm: 62, meaPermille: 78, ownerName: "Frau Becker", ownerSince: 2014, tenant: "Frau Becker (self)", rentEur: null, beirat: false },
  { id: "u-2b", propertyId: "p1", label: "2B", type: "residential", areaQm: 71, meaPermille: 89, ownerName: "Herr Bauer", ownerSince: 2019, tenant: "Herr Bauer (self)", rentEur: null, beirat: false },
  { id: "u-3b", propertyId: "p1", label: "3B", type: "residential", areaQm: 58, meaPermille: 73, ownerName: "Schmidt GbR", ownerSince: 2002, tenant: "Herr Schmidt", rentEur: 890, beirat: false },
  { id: "u-4a", propertyId: "p1", label: "4A", type: "residential", areaQm: 84, meaPermille: 105, ownerName: "Frau Müller", ownerSince: 2021, tenant: "Frau Müller (self)", rentEur: null, beirat: false },
  { id: "u-5c", propertyId: "p1", label: "5C", type: "residential", areaQm: 55, meaPermille: 69, ownerName: "Wagner KG", ownerSince: 2017, tenant: "Frau Wagner", rentEur: 840, beirat: false },
  { id: "u-6b", propertyId: "p1", label: "6B", type: "residential", areaQm: 66, meaPermille: 83, ownerName: "Ostrowski GmbH", ownerSince: 2020, tenant: "Herr Ostrowski", rentEur: 970, beirat: false },
  { id: "u-7a", propertyId: "p1", label: "7A", type: "residential", areaQm: 90, meaPermille: 113, ownerName: "Herr Klein", ownerSince: 2008, tenant: "Herr Klein (self)", rentEur: null, beirat: true },
  { id: "u-e1", propertyId: "p1", label: "E1", type: "commercial", areaQm: 120, meaPermille: 150, ownerName: "Klein Invest UG", ownerSince: 2015, tenant: "Café Bernstein", rentEur: 2400, beirat: false },
];

// ============================================================
// VENDORS
// ============================================================
export const vendors: Vendor[] = [
  { id: "v1", name: "Heinz GmbH", trade: "HVAC", contact: "Herr Heinz", phone: "+49 30 4411 8800", email: "dispatch@heinz-hvac.de", rating: 4.7, preferred: true, buildings: ["b1", "b2"], slaHours: 24 },
  { id: "v2", name: "Bekey Service", trade: "Locks & Intercom", contact: "Frau Bekey", phone: "+49 30 9912 0044", email: "service@bekey.de", rating: 4.5, preferred: true, buildings: ["b1", "b3"], slaHours: 4 },
  { id: "v3", name: "Wasser Schmidt", trade: "Plumbing", contact: "Herr Schmidt", phone: "+49 30 7733 4422", email: "kontakt@wasser-schmidt.de", rating: 4.2, preferred: false, buildings: ["b1"], slaHours: 8 },
  { id: "v4", name: "Berlin Elektro", trade: "Electrical", contact: "Herr Becker", phone: "+49 30 6622 5588", email: "buero@berlin-elektro.de", rating: 4.4, preferred: true, buildings: ["b2", "b3"], slaHours: 24 },
];

export const vendorCases: VendorCase[] = [
  { id: "vc1", vendorId: "v1", propertyId: "p1", date: "2025-11-04", description: "Heating cold — valve replacement Unit 3B", costEur: 165, slaMet: true, rating: 5 },
  { id: "vc2", vendorId: "v1", propertyId: "p1", date: "2024-03-15", description: "Annual heating service", costEur: 320, slaMet: true, rating: 5 },
  { id: "vc3", vendorId: "v1", propertyId: "p2", date: "2025-08-22", description: "Boiler ignition fault Unit 4D", costEur: 220, slaMet: true, rating: 4 },
  { id: "vc4", vendorId: "v2", propertyId: "p1", date: "2026-02-11", description: "Intercom firmware update", costEur: 90, slaMet: true, rating: 5 },
  { id: "vc5", vendorId: "v3", propertyId: "p1", date: "2025-09-30", description: "Drain clog kitchen Unit 5C", costEur: 145, slaMet: false, rating: 3 },
];

// ============================================================
// PIPELINE STAGES
// ============================================================
export const pipelineStages: PipelineStage[] = [
  { id: "new",            label: "New",              description: "Inbound landed — agent hasn't looked yet" },
  { id: "triaged",        label: "Triaged",          description: "Classified — proposal being drafted" },
  { id: "proposed",       label: "Awaiting approval", description: "Operator decision required" },
  { id: "awaiting_vendor",label: "Vendor coord.",    description: "SMS sent, waiting on vendor" },
  { id: "scheduled",      label: "Scheduled",        description: "Vendor confirmed, work pending" },
  { id: "completed",      label: "Completed",        description: "Vendor reports done — memory decision pending" },
];

// ============================================================
// TICKETS
// ============================================================
export const tickets: Ticket[] = [
  {
    id: "t-7831",
    num: "GAR-118",
    propertyId: "p1",
    unitId: "u-3b",
    source: "voice",
    status: "proposed",
    risk: "medium",
    subject: "Heating cold — Unit 3B",
    excerpt: "Tenant called from a café. Radiator in living room not heating since Tuesday. Mobility flag.",
    raisedBy: "Herr Schmidt",
    raisedByPhone: "+49 170 2233 445",
    createdAt: "2026-04-25T08:14:00Z",
    confidence: 0.86,
    callSession: {
      duration: "1:27",
      callerPhone: "+49 170 2233 445",
      summary: "Living-room radiator cold since Tuesday. Tenant has mobility limitation, requests written confirmation.",
      noiseReductionDb: 18,
      transcript: [
        { spk: "agent",  t: "0:00", text: "Buena Hausverwaltung, guten Tag.",                             en: "Buena property management, good day." },
        { spk: "tenant", t: "0:03", text: "Guten Tag, hier Schmidt aus der Gartenstraße 42, Wohnung 3B.", en: "Good day, this is Schmidt from Gartenstraße 42, apartment 3B." },
        { spk: "tenant", t: "0:09", text: "Die Heizung im Wohnzimmer ist seit Dienstag kalt.",            en: "The radiator in the living room has been cold since Tuesday." },
        { spk: "agent",  t: "0:14", text: "Danke. Geben Sie mir kurz Zeit zum Nachschauen.",              en: "Thank you. Give me a moment to check." },
        { spk: "tenant", t: "0:19", text: "Können Sie mir bitte schriftlich bestätigen, wann jemand kommt?", en: "Can you please confirm in writing when someone will come?" },
        { spk: "agent",  t: "0:24", text: "Ja, Sie bekommen eine schriftliche Bestätigung per E-Mail.",   en: "Yes, you will receive written confirmation by email." },
      ],
    },
    proposal: {
      id: "pr-7831",
      confidence: 0.86,
      contextVersion: 11,
      proposedAction: {
        type: "dispatch_vendor",
        vendor: "Heinz GmbH",
        vendorId: "v1",
        trade: "HVAC",
        target: "Unit 3B radiator (living room)",
        estimateEur: 175,
        etaHours: 24,
      },
      reasoning:
        "Same symptom as 2025-11 (Unit 3B valve replacement, €165, Heinz). Cost is €25 below the €200 auto-approval threshold. Mobility flag in tenant context requires written confirmation in Sie-Form.",
      citations: [
        { heading: "Unit 3B history", excerpt: "Valve replaced 2025-11-08 by Heinz GmbH (€165). Same radiator." },
        { heading: "Vendors", excerpt: "Heinz GmbH preferred for HVAC — SLA 24h, rating 4.7." },
        { heading: "Tenant Schmidt — accessibility", excerpt: "Mobility limitation. All correspondence requires written confirmation in Sie-Form." },
      ],
      policiesEvaluated: [
        { code: "P1", name: "approval_threshold (€175 ≤ €200)", passed: true },
        { code: "P4", name: "vendor_preference (Heinz GmbH)", passed: true },
        { code: "P5", name: "callback_required (mobility flag)", passed: true },
      ],
    },
    // memoryProposal intentionally omitted — appears AFTER vendor closes the job
  },
  {
    id: "t-7830",
    num: "GAR-117",
    propertyId: "p1",
    unitId: "u-5c",
    source: "email",
    status: "proposed",
    risk: "low",
    subject: "Kitchen drain slow — Unit 5C",
    excerpt: "Hello, the kitchen sink in Unit 5C is draining very slowly again. Last time we had Wasser Schmidt, can we book them again?",
    raisedBy: "Frau Wagner",
    createdAt: "2026-04-25T07:42:00Z",
    confidence: 0.91,
    emailBody:
      "Hello,\n\nThe kitchen sink in Unit 5C is draining very slowly again. Last time we had Wasser Schmidt come out (September), can we book them again?\n\nBest,\nFrau Wagner",
    proposal: {
      id: "pr-7830",
      confidence: 0.91,
      contextVersion: 11,
      proposedAction: {
        type: "dispatch_vendor",
        vendor: "Wasser Schmidt",
        vendorId: "v3",
        trade: "Plumbing",
        target: "Unit 5C kitchen drain",
        estimateEur: 145,
        etaHours: 8,
      },
      reasoning:
        "Recurring symptom from same unit. Wasser Schmidt previously serviced this drain in 2025-09 (€145). Estimate matches prior cost. Within €200 threshold.",
      citations: [
        { heading: "Unit 5C history", excerpt: "Drain clog 2025-09-30 by Wasser Schmidt (€145). SLA missed by 2h — flag for follow-up." },
        { heading: "Vendors", excerpt: "Wasser Schmidt — plumbing, SLA 8h, rating 4.2." },
      ],
      policiesEvaluated: [
        { code: "P1", name: "approval_threshold (€145 ≤ €200)", passed: true },
        { code: "P4", name: "vendor_preference (recurring)", passed: true },
      ],
    },
  },
  {
    id: "t-7825",
    num: "GAR-112",
    propertyId: "p1",
    unitId: "u-6b",
    source: "voice",
    status: "completed",
    risk: "low",
    subject: "Intercom not working — Unit 6B",
    excerpt: "Intercom dead since yesterday. Bekey replaced module.",
    raisedBy: "Herr Ostrowski",
    createdAt: "2026-04-22T14:00:00Z",
    confidence: 0.94,
    vendorJob: {
      vendorId: "v2",
      sentAt: "2026-04-22T14:32:00Z",
      accepted: true,
      scheduledFor: "2026-04-23T10:00:00Z",
      completedAt: "2026-04-23T11:05:00Z",
      finalCostEur: 90,
      notes: "Replaced intercom call module. Tested all units — working.",
    },
    // Memory decision is now PENDING because vendor reported completion.
    memoryProposal: {
      text: "Unit 6B intercom call module replaced 2026-04-23 by Bekey Service (€90). Same fault as 2024-11.",
      targetVersion: 12,
      status: "pending",
    },
  },
  {
    id: "t-7820",
    num: "GAR-105",
    propertyId: "p1",
    unitId: "u-e1",
    source: "email",
    status: "resolved",
    risk: "low",
    subject: "Café signage permit reminder",
    excerpt: "Annual signage permit renewal — handled.",
    raisedBy: "Café Bernstein",
    createdAt: "2026-04-10T09:00:00Z",
  },
  {
    id: "t-7818",
    num: "BRU-051",
    propertyId: "p2",
    source: "voice",
    status: "proposed",
    risk: "high",
    subject: "Elevator stuck between floors",
    excerpt: "Elevator stuck — tenant inside. Safety call routed to Schindler.",
    raisedBy: "Multiple tenants",
    createdAt: "2026-04-25T08:55:00Z",
    confidence: 0.78,
  },
];
