export type Layer = "vendor" | "owner" | "building" | "property";

export type TicketStatus =
  | "new"
  | "triaged"
  | "proposed"
  | "approved"
  | "awaiting_vendor"
  | "scheduled"
  | "in_progress"
  | "completed"
  | "resolved"
  | "rejected";

export type Risk = "low" | "medium" | "high";
export type Source = "voice" | "email" | "slack" | "manual" | "api";

export interface Owner {
  id: string;
  name: string;
  type: "weg" | "private" | "company";
  contact: string;
  email: string;
  phone: string;
  language: "de" | "en";
  notes?: string;
  buildingsCount: number;
  unitsCount: number;
  monthlyRevenueEur: number;
  policies: string[];
  decisions: { date: string; text: string }[];
}

export interface Building {
  id: string;
  name: string;
  ownerId: string;
  address: string;
  city: string;
  yearBuilt: number;
  units: number;
  systems: { hvac?: string; heating?: string; elevator?: string; intercom?: string };
  vendors: string[]; // vendor ids
  notes?: string;
}

export interface Property {
  id: string;
  name: string;
  buildingId: string;
  ownerId: string;
  city: string;
  units: number;
  openTickets: number;
  contextVersion: number;
  phone: string;
  email: string;
}

export interface Unit {
  id: string;
  propertyId: string;
  label: string;
  type: "residential" | "commercial";
  areaQm: number;
  meaPermille: number;
  ownerName: string;
  ownerSince: number;
  tenant: string;
  rentEur: number | null;
  beirat: boolean;
}

export interface Vendor {
  id: string;
  name: string;
  trade: string;
  contact: string;
  phone: string;
  email: string;
  rating: number;
  preferred: boolean;
  buildings: string[];
  slaHours: number;
}

export interface VendorCase {
  id: string;
  vendorId: string;
  propertyId: string;
  date: string;
  description: string;
  costEur: number;
  slaMet: boolean;
  rating: number;
}

export interface Citation {
  heading: string;
  excerpt: string;
}

export interface ProposedAction {
  type: string;
  vendor: string;
  vendorId: string;
  trade: string;
  target: string;
  estimateEur: number;
  etaHours: number;
}

export interface Ticket {
  id: string;
  num: string;
  propertyId: string;
  unitId?: string;
  source: Source;
  status: TicketStatus;
  risk: Risk;
  subject: string;
  excerpt: string;
  raisedBy: string;
  raisedByPhone?: string;
  createdAt: string;
  confidence?: number;
  proposal?: {
    id: string;
    confidence: number;
    contextVersion: number;
    proposedAction: ProposedAction;
    reasoning: string;
    citations: Citation[];
    policiesEvaluated: { code: string; name: string; passed: boolean }[];
  };
  callSession?: {
    duration: string;
    callerPhone: string;
    summary: string;
    transcript: { spk: "tenant" | "agent"; t: string; text: string; en: string }[];
    noiseReductionDb: number;
  };
  emailBody?: string;
  // Memory decision is set ONLY after the vendor closes the job.
  memoryProposal?: {
    text: string;
    targetVersion: number;
    status: "pending" | "saved" | "skipped";
  };
  vendorJob?: {
    vendorId: string;
    sentAt: string;
    accepted: boolean;
    scheduledFor?: string;
    completedAt?: string;
    finalCostEur?: number;
    notes?: string;
  };
}

export interface PipelineStage {
  id: TicketStatus;
  label: string;
  description: string;
}

export interface AgentMessage {
  role: "user" | "assistant" | "system";
  content: string;
  scope?: { layer: Layer; id?: string };
  appliedTo?: { layer: Layer; id: string; version: number }[];
  timestamp: string;
}
